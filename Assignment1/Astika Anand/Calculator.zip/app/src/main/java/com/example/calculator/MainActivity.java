package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = (EditText)findViewById(R.id.editText1);
        e2 = (EditText)findViewById(R.id.editText2);
        b1 = (Button)findViewById(R.id.button);
        b2 = (Button)findViewById(R.id.button2);
        b3 = (Button)findViewById(R.id.button3);
        b4 = (Button)findViewById(R.id.button4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2)){
                    Toast.makeText(MainActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
                }
                else{
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    int n = n1+n2;
                    Toast.makeText(MainActivity.this,n+"",Toast.LENGTH_LONG).show();
                }

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2)){
                    Toast.makeText(MainActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
                }
                else{
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    int n = n1-n2;
                    Toast.makeText(MainActivity.this,n+"",Toast.LENGTH_LONG).show();
                }

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2)){
                    Toast.makeText(MainActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
                }
                else{
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    int n = n1*n2;
                    Toast.makeText(MainActivity.this,n+"",Toast.LENGTH_LONG).show();
                }

            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2) || TextUtils.equals(s2,"0")){
                    Toast.makeText(MainActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
                }
                else{
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    int n = n1/n2;
                    Toast.makeText(MainActivity.this,n+"",Toast.LENGTH_LONG).show();
                }

            }
        });
    }


}