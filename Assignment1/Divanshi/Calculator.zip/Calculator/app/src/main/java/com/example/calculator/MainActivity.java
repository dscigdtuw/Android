package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    android.widget.EditText e1;
    android.widget.EditText e2;
    android.widget.TextView e3;
    Button b1;
    Button b2;
    Button b3;
    Button b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = (android.widget.EditText) findViewById(R.id.editTextTextPersonName);
        e2 = (android.widget.EditText) findViewById(R.id.editTextTextPersonName2);
        e3 = (android.widget.TextView) findViewById(R.id.textView2);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1)||TextUtils.isEmpty(s2))
                {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                }
                else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    e3.setText(n1 + n2 + "");
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1)||TextUtils.isEmpty(s2))
                {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                }
                else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    e3.setText(n1 - n2 + "");
                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1)||TextUtils.isEmpty(s2))
                {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                }
                else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    e3.setText(n1 * n2 + "");
                }
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                if(TextUtils.isEmpty(s1)||TextUtils.isEmpty(s2))
                {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                }
                else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    e3.setText(n1 / n2 + "");
                }
            }
        });

    }
}