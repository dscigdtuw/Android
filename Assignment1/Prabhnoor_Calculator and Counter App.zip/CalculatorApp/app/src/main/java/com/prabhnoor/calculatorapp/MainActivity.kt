package com.prabhnoor.calculatorapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var add:Button
    lateinit var sub:Button
    lateinit var divide:Button
    lateinit var product:Button
    lateinit var num1: EditText
    lateinit var num2: EditText
    lateinit var output:TextView
    lateinit var tocounter:Button
    lateinit var clear:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tocounter=findViewById(R.id.btntocounter)
        tocounter.setOnClickListener {
            val intent= Intent(this@MainActivity, CounterActivity::class.java)
            startActivity(intent)
        }
        clear=findViewById(R.id.btnClear)
        clear.setOnClickListener {
            num1.clearComposingText()
            num2.clearComposingText()
        }
        add=findViewById(R.id.add)
        sub=findViewById(R.id.sub)
        product=findViewById(R.id.product)
        divide=findViewById(R.id.divide)
        num1=findViewById(R.id.etNum1)
        num2=findViewById(R.id.etNum2)
        output=findViewById(R.id.txtOutput)
        var a= Integer.parseInt(num1.text.toString())
        var b= Integer.parseInt(num2.text.toString())
        add.setOnClickListener {
            output.text=doSum(a,b)
         }
        sub.setOnClickListener {
            output.text=doSubtract(a,b)
        }
        product.setOnClickListener {
            output.text=doProduct(a,b)
        }
        divide.setOnClickListener {
            output.text=doDivide(a,b)
        }
    }
    private fun doSum(a:Int, b:Int):String{
        val c=a+b
        return c.toString()
    }
    private fun doSubtract(a:Int, b:Int):String{
        val c=a-b
        return c.toString()
    }
    private fun doProduct(a:Int, b:Int):String{
        val c=a*b
        return c.toString()
    }
    private fun doDivide(a:Int, b:Int):String{
        val c=a/b
        return c.toString()
    }
}