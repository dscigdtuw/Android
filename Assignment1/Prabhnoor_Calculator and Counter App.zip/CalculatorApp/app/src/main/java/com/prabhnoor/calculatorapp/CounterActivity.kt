package com.prabhnoor.calculatorapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_counter.*


class CounterActivity : AppCompatActivity() {
    lateinit var displaycount:TextView
    lateinit var iterate:Button
    lateinit var goback:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_counter)
        displaycount=findViewById(R.id.txtNum)
        iterate= findViewById(R.id.btnCount)
        goback=findViewById(R.id.btnBack)
        var num=Integer.parseInt(iterate.text.toString())
        iterate.setOnClickListener {
            num++
            iterate.text=num.toString()
        }
        btnBack.setOnClickListener {
            val intent= Intent(this@CounterActivity, MainActivity::class.java)
            startActivity(intent)
        }
    }
}